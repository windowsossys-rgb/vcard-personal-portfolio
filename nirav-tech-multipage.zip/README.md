# Nirav Tech multi-page portfolio

Upload these files to the root of your GitHub Pages repository.

Routes: `/`, `/about/`, `/projects/`, `/blog/`, `/contact/`, plus individual blog article routes.

The contact page uses `mailto:` so it works on static GitHub Pages without a backend.
